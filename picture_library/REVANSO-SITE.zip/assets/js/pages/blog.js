(function ($) {
    "use strict";
  
  
  })(jQuery);